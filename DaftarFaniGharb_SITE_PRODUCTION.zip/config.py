SHOP_NAME = 'دفتر فنی غرب'
SHOP_PHONE = '021-44079569'
SHOP_ADDRESS = 'تهران، خیابان آیت‌الله کاشانی، بلوار شقایق شمالی، کوچه یکم پرواز، پلاک ۸'
ADMIN_USER = 'admin'
ADMIN_PASSWORD = 'CHANGE-THIS-PASSWORD'
SECRET_KEY = 'CHANGE-THIS-SECRET-KEY'

SITE_URL = 'https://www.daftarfanigharb.ir'
