import os, re, sqlite3, secrets, time, hashlib
from pathlib import Path
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, abort
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / 'uploads'
PUBLIC_UPLOADS = UPLOADS / 'public'
PRIVATE_UPLOADS = UPLOADS / 'private'
for _d in (UPLOADS, PUBLIC_UPLOADS, PRIVATE_UPLOADS): _d.mkdir(exist_ok=True)

DB = BASE / 'shop.db'
SITE_URL = os.getenv('SITE_URL', 'https://www.daftarfanigharb.ir')
ALLOWED = {'pdf','doc','docx','jpg','jpeg','png','dwg','dxf','zip'}

try:
    from config import SHOP_NAME, SHOP_PHONE, SHOP_ADDRESS, ADMIN_USER, ADMIN_PASSWORD, SECRET_KEY
except Exception:
    SHOP_NAME, SHOP_PHONE, SHOP_ADDRESS = 'دفتر فنی غرب', '021-44079569', 'تهران، خیابان آیت‌الله کاشانی، بلوار شقایق شمالی، کوچه یکم پرواز، پلاک ۸'
    ADMIN_USER, ADMIN_PASSWORD, SECRET_KEY = 'admin', 'CHANGE-THIS-PASSWORD', secrets.token_hex(32)

# Production switches to PostgreSQL only when DATABASE_URL is provided by Render.
USE_POSTGRES = bool(os.getenv('DATABASE_URL', '').strip())

# Production must use explicit secrets supplied by Render Environment Variables.
if USE_POSTGRES:
    if not os.getenv('SECRET_KEY','').strip() or str(SECRET_KEY).startswith('CHANGE-THIS'):
        raise RuntimeError('Production configuration error: set SECRET_KEY in Render Environment Variables.')
    if not os.getenv('ADMIN_PASSWORD_HASH','').strip():
        raise RuntimeError('Production configuration error: set ADMIN_PASSWORD_HASH in Render Environment Variables.')
# Local development may generate a temporary secret automatically.
if not SECRET_KEY or str(SECRET_KEY).startswith('CHANGE-THIS'):
    SECRET_KEY = secrets.token_hex(48)

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config['MAX_CONTENT_LENGTH'] = 30 * 1024 * 1024
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE', '1' if USE_POSTGRES else '0') == '1',
    PERMANENT_SESSION_LIFETIME=60*60*24*7,
)
LOGIN_LIMIT = {}
TRACK_LIMIT = {}
OTP_LIMIT = {}

def _rate_ok(key, limit=8, window=300):
    now=time.time(); arr=[t for t in LOGIN_LIMIT.get(key,[]) if now-t < window]
    if len(arr) >= limit:
        LOGIN_LIMIT[key]=arr
        return False
    arr.append(now); LOGIN_LIMIT[key]=arr
    return True

@app.before_request
def security_before_request():
    if 'csrf_token' not in session:
        session['csrf_token']=secrets.token_urlsafe(32)
    if request.method == 'POST':
        supplied=request.form.get('_csrf','')
        expected=session.get('csrf_token','')
        if not supplied or not secrets.compare_digest(str(supplied),str(expected)):
            abort(400, description='درخواست نامعتبر است. صفحه را تازه‌سازی کنید.')

@app.after_request
def security_headers(response):
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    response.headers['Cross-Origin-Opener-Policy']='same-origin'
    response.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
    if request.is_secure:
        response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    if request.path.startswith(('/admin','/auth','/verify-phone','/track','/checkout')):
        response.headers['Cache-Control']='no-store'
    return response

@app.context_processor
def csrf_context():
    return {'csrf_token': lambda: session.get('csrf_token','')}

@app.template_filter('comma')
def comma(value):
    try: return f'{int(value):,}'
    except Exception: return value

# Paper types are intentionally limited to print/copy services only.
PAPER_OPTIONS = [
    {'code':'plain','title':'برگه معمولی'},
    {'code':'glossy135','title':'گلاسه ۱۳۵ گرم'},
    {'code':'matte120','title':'کند ۱۲۰ گرم'},
    {'code':'paper160','title':'۱۶۰ گرم'},
    {'code':'paper250','title':'۲۵۰ گرم'},
]
PAPER_MAP = {p['code']:p['title'] for p in PAPER_OPTIONS}

SERVICES = [
    {'code':'copy_bw','title':'کپی سیاه‌وسفید','icon':'▣','price_code':'copy_bw','unit':'هر برگ','needs_file':True,'sizes':['A4','A5','A3'],'paper':True},
    {'code':'copy_color','title':'کپی رنگی','icon':'◈','price_code':'copy_color','unit':'هر برگ','needs_file':True,'sizes':['A4','A5','A3'],'paper':True},
    {'code':'print_bw','title':'پرینت سیاه‌وسفید','icon':'🖨️','price_code':'print_bw','unit':'هر برگ','needs_file':True,'sizes':['A4','A5','A3'],'paper':True},
    {'code':'print_color','title':'پرینت رنگی','icon':'🎨','price_code':'print_color','unit':'هر برگ','needs_file':True,'sizes':['A4','A5','A3'],'paper':True},
    {'code':'plot_bw','title':'پلات سیاه‌وسفید','icon':'▤','price_code':'plot_bw','unit':'هر برگ','needs_file':True,'sizes':['A4','A2','A1','A0'],'paper':False},
    {'code':'plot_color','title':'پلات رنگی','icon':'▧','price_code':'plot_color','unit':'هر برگ','needs_file':True,'sizes':['A4','A2','A1','A0'],'paper':False},
    {'code':'scan_color_bw','title':'اسکن رنگی و سیاه‌وسفید','icon':'◎','price_code':'scan_color_bw','unit':'هر برگ','needs_file':False,'sizes':['A4','A5','A3'],'paper':False},
    {'code':'binding_spiral','title':'صحافی فنری','icon':'▥','price_code':'binding_spiral','unit':'هر جلد','needs_file':False,'sizes':['A4','A5','A3'],'paper':False},
    {'code':'binding_cover_strip','title':'طلق و شیرازه','icon':'◇','price_code':'binding_cover_strip','unit':'هر جلد','needs_file':False,'sizes':['A4','A5','A3'],'paper':False},
    {'code':'laminate','title':'لمینت','icon':'✨','price_code':'laminate','unit':'هر برگ','needs_file':False,'sizes':['A4','A5','A3','A2'],'paper':False},
]

# Keep a complete admin pricing matrix, but start every amount at zero.
# No price is shown to customers until the owner enters it from the admin panel.
DEFAULT_PRICES=[]
def add_price(title, code, unit='هر برگ'):
    DEFAULT_PRICES.append((title,code,0,unit))
for svc in ['copy_bw','copy_color','print_bw','print_color']:
    title=next(s['title'] for s in SERVICES if s['code']==svc)
    for size in ['A4','A5','A3']:
        for paper in PAPER_OPTIONS:
            add_price(f'{title} {size} - {paper["title"]}', f'{svc}_{size}_{paper["code"]}')
for svc, sizes in [('plot_bw',['A4','A2','A1','A0']),('plot_color',['A4','A2','A1','A0']),('scan_color_bw',['A4','A5','A3']),('binding_spiral',['A4','A5','A3']),('binding_cover_strip',['A4','A5','A3']),('laminate',['A4','A5','A3','A2'])]:
    title=next(s['title'] for s in SERVICES if s['code']==svc)
    unit='هر جلد' if svc in {'binding_spiral','binding_cover_strip'} else 'هر برگ'
    for size in sizes: add_price(f'{title} {size}',f'{svc}_{size}',unit)


class DBConn:
    def __init__(self, raw): self.raw=raw
    def execute(self, sql, params=()): return _pg_exec(self.raw,sql,params) if USE_POSTGRES else self.raw.execute(sql,params)
    def executescript(self, sql): return self.raw.execute(sql)
    def commit(self): return self.raw.commit()
    def close(self): return self.raw.close()
    def __getattr__(self,n): return getattr(self.raw,n)

def _pg_exec(c, sql, params=None):
    return c.execute(sql.replace('?', '%s'), params or ())

def db():
    if USE_POSTGRES:
        return DBConn(psycopg.connect(os.environ['DATABASE_URL'], row_factory=dict_row))
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return DBConn(c)

def init_db():
    c=db()
    if USE_POSTGRES:
        schema="""
        CREATE TABLE IF NOT EXISTS prices(id BIGSERIAL PRIMARY KEY,title TEXT NOT NULL,code TEXT UNIQUE NOT NULL,amount BIGINT NOT NULL,unit TEXT NOT NULL,active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS orders(id BIGSERIAL PRIMARY KEY,order_code TEXT UNIQUE NOT NULL,customer_name TEXT,phone TEXT NOT NULL,service TEXT NOT NULL,size TEXT,quantity INTEGER NOT NULL,duplex TEXT,options TEXT,filename TEXT,stored_name TEXT,amount BIGINT NOT NULL,status TEXT NOT NULL DEFAULT 'received',payment_status TEXT NOT NULL DEFAULT 'unpaid',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS products(id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,description TEXT,price BIGINT NOT NULL,image TEXT,active INTEGER DEFAULT 1,category TEXT DEFAULT 'stationery',subcategory TEXT DEFAULT '',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS otp_codes(id BIGSERIAL PRIMARY KEY,phone TEXT NOT NULL,code_hash TEXT NOT NULL,expires_at BIGINT NOT NULL,attempts INTEGER DEFAULT 0,verified INTEGER DEFAULT 0,created_at BIGINT NOT NULL);
        CREATE TABLE IF NOT EXISTS users(id BIGSERIAL PRIMARY KEY,username TEXT UNIQUE NOT NULL,name TEXT NOT NULL,phone TEXT,password_hash TEXT NOT NULL,created_at BIGINT NOT NULL,last_login BIGINT);
        CREATE TABLE IF NOT EXISTS lucky_spins(id BIGSERIAL PRIMARY KEY,phone TEXT NOT NULL,result TEXT NOT NULL,day_key TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
        CREATE INDEX IF NOT EXISTS idx_lucky_spins_phone_day ON lucky_spins(phone,day_key);
        CREATE INDEX IF NOT EXISTS idx_products_category_active ON products(category,active);
        CREATE INDEX IF NOT EXISTS idx_orders_phone_code ON orders(phone,order_code);
        """
        c.execute(schema)
        cols={r['column_name'] for r in c.execute("SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name='products'").fetchall()}
        if 'category' not in cols: c.execute("ALTER TABLE products ADD COLUMN category TEXT DEFAULT 'stationery'")
        if 'subcategory' not in cols: c.execute("ALTER TABLE products ADD COLUMN subcategory TEXT DEFAULT ''")
    else:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS prices(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,code TEXT UNIQUE NOT NULL,amount INTEGER NOT NULL,unit TEXT NOT NULL,active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,order_code TEXT UNIQUE NOT NULL,customer_name TEXT,phone TEXT NOT NULL,service TEXT NOT NULL,size TEXT,quantity INTEGER NOT NULL,duplex TEXT,options TEXT,filename TEXT,stored_name TEXT,amount INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'received',payment_status TEXT NOT NULL DEFAULT 'unpaid',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT,price INTEGER NOT NULL,image TEXT,active INTEGER DEFAULT 1,category TEXT DEFAULT 'stationery',subcategory TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS otp_codes(id INTEGER PRIMARY KEY AUTOINCREMENT,phone TEXT NOT NULL,code_hash TEXT NOT NULL,expires_at INTEGER NOT NULL,attempts INTEGER DEFAULT 0,verified INTEGER DEFAULT 0,created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,name TEXT NOT NULL,phone TEXT,password_hash TEXT NOT NULL,created_at INTEGER NOT NULL,last_login INTEGER);
        CREATE TABLE IF NOT EXISTS lucky_spins(id INTEGER PRIMARY KEY AUTOINCREMENT,phone TEXT NOT NULL,result TEXT NOT NULL,day_key TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
        CREATE INDEX IF NOT EXISTS idx_lucky_spins_phone_day ON lucky_spins(phone,day_key);
        CREATE INDEX IF NOT EXISTS idx_products_category_active ON products(category,active);
        CREATE INDEX IF NOT EXISTS idx_orders_phone_code ON orders(phone,order_code);
        ''')
        cols={r['name'] for r in c.execute('PRAGMA table_info(products)').fetchall()}
        if 'category' not in cols: c.execute("ALTER TABLE products ADD COLUMN category TEXT DEFAULT 'stationery'")
        if 'subcategory' not in cols: c.execute("ALTER TABLE products ADD COLUMN subcategory TEXT DEFAULT ''")
    c.execute("UPDATE products SET category='stationery' WHERE category IS NULL OR category=''")
    stationery_names=['دفتر','خودکار','مداد رنگی','پاک‌کن','خط‌کش','گونیا','دستگاه منگنه','چسب ماتیکی']
    stationery_visuals={'دفتر':'stationery_notebook_final.jpg','خودکار':'stationery_pen_final.jpg','مداد رنگی':'stationery_colored_pencils_final.jpg','پاک‌کن':'stationery_eraser_final.jpg','خط‌کش':'stationery_ruler_final.jpg','گونیا':'stationery_squares_final.jpg','دستگاه منگنه':'stationery_stapler_final.jpg','چسب ماتیکی':'stationery_glue_final.jpg'}
    existing={r['name'] for r in c.execute("SELECT name FROM products WHERE category='stationery'").fetchall()}
    for idx,nm in enumerate(stationery_names,1):
        placeholder=stationery_visuals.get(nm,f'stationery_{idx:02d}.svg')
        if nm not in existing:
            c.execute("INSERT INTO products(name,description,price,image,active,category,subcategory) VALUES(?,?,?,?,1,'stationery','')",(nm,'تصویر و قیمت این محصول را از پنل مدیریت قابل تغییر کن.',0,placeholder))
        else:
            row=c.execute("SELECT image FROM products WHERE category='stationery' AND name=?",(nm,)).fetchone()
            current=(row['image'] or '') if row else ''
            if (not current) or current.startswith('stationery_0') or current.endswith('.svg'):
                c.execute("UPDATE products SET image=? WHERE category='stationery' AND name=?",(placeholder,nm))
    demo_categories=[('memorial','آگهی ترحیم نمونه ۱','نمونه نمایشی؛ تصویر و قیمت واقعی را از پنل مدیریت جایگزین کن.','memorial_demo_01.svg','تسلیت'),('memorial','آگهی ترحیم نمونه ۲','نمونه نمایشی؛ تصویر و قیمت واقعی را از پنل مدیریت جایگزین کن.','memorial_demo_02.svg','تسلیت'),('memorial','آگهی ترحیم نمونه ۳','نمونه نمایشی؛ تصویر و قیمت واقعی را از پنل مدیریت جایگزین کن.','memorial_demo_03.svg','تسلیت'),('portfolio','نمونه‌کار چاپ','نمونه نمایشی؛ عکس واقعی کار مغازه را از پنل مدیریت جایگزین کن.','portfolio_demo_01.svg','چاپ'),('portfolio','نمونه‌کار طراحی','نمونه نمایشی؛ عکس واقعی کار مغازه را از پنل مدیریت جایگزین کن.','portfolio_demo_02.svg','طراحی'),('portfolio','نمونه‌کار صحافی','نمونه نمایشی؛ عکس واقعی کار مغازه را از پنل مدیریت جایگزین کن.','portfolio_demo_03.svg','صحافی'),('printing','کارت ویزیت نمونه','نمونه نمایشی؛ عکس واقعی کارت ویزیت و قیمت را از پنل مدیریت جایگزین کن.','printing_demo_01.svg','کارت ویزیت'),('printing','سربرگ نمونه','نمونه نمایشی؛ عکس واقعی سربرگ و قیمت را از پنل مدیریت جایگزین کن.','printing_demo_02.svg','سربرگ'),('banner','بنر تسلیت نمونه ۱','نمونه نمایشی؛ عکس بنر واقعی و قیمت را از پنل مدیریت جایگزین کن.','banner_demo_01.svg','تسلیت'),('banner','بنر تسلیت نمونه ۲','نمونه نمایشی؛ عکس بنر واقعی و قیمت را از پنل مدیریت جایگزین کن.','banner_demo_02.svg','تسلیت'),('banner','بنر نمونه ۳','نمونه نمایشی؛ عکس بنر واقعی و قیمت را از پنل مدیریت جایگزین کن.','banner_demo_03.svg','بنر')]
    for cat,nm,desc,img,sub in demo_categories:
        if c.execute("SELECT 1 FROM products WHERE category=? AND name=? LIMIT 1",(cat,nm)).fetchone() is None:
            c.execute("INSERT INTO products(name,description,price,image,active,category,subcategory) VALUES(?,?,?,?,1,?,?)",(nm,desc,0,img,cat,sub))
    for row in DEFAULT_PRICES:
        if USE_POSTGRES: c.execute('INSERT INTO prices(title,code,amount,unit) VALUES(%s,%s,%s,%s) ON CONFLICT (code) DO NOTHING',row)
        else: c.execute('INSERT OR IGNORE INTO prices(title,code,amount,unit) VALUES(?,?,?,?)',row)
    c.execute("DELETE FROM prices WHERE code LIKE 'binding_cover_%' OR code LIKE 'binding_strip_%'")
    c.execute("DELETE FROM prices WHERE code LIKE 'scan_bw_%'")
    c.commit(); c.close()
init_db()

def normalize_phone(phone):
    phone=''.join(ch for ch in phone if ch.isdigit() or ch=='+')
    if phone.startswith('+98'): phone='0'+phone[3:]
    elif phone.startswith('0098'): phone='0'+phone[4:]
    return phone

def valid_phone(phone): return bool(re.fullmatch(r'09\d{9}',phone))

def send_otp_sms(phone, code):
    provider=os.getenv('SMS_PROVIDER_URL','').strip(); key=os.getenv('SMS_API_KEY','').strip(); sender=os.getenv('SMS_SENDER','').strip()
    if not provider or not key:
        app.logger.warning('DEV OTP for %s: %s', phone, code); return True
    try:
        import requests
        r=requests.post(provider,json={'to':phone,'message':f'کد تایید دفتر فنی غرب: {code}','sender':sender},headers={'Authorization':f'Bearer {key}'},timeout=15)
        return 200 <= r.status_code < 300
    except Exception as e:
        app.logger.error('SMS provider error: %s',e); return False

def create_otp(phone):
    now=int(time.time()); code=f'{secrets.randbelow(1000000):06d}'; c=db()
    c.execute('DELETE FROM otp_codes WHERE phone=? OR expires_at<?',(phone,now)); c.execute('INSERT INTO otp_codes(phone,code_hash,expires_at,created_at) VALUES(?,?,?,?)',(phone,hashlib.sha256(code.encode()).hexdigest(),now+180,now)); c.commit(); c.close()
    sent=send_otp_sms(phone,code)
    if not os.getenv('SMS_PROVIDER_URL','').strip() or not os.getenv('SMS_API_KEY','').strip(): session['dev_otp_code']=code
    else: session.pop('dev_otp_code',None)
    return sent

def verify_otp(phone,code):
    now=int(time.time()); digest=hashlib.sha256(code.encode()).hexdigest(); c=db(); row=c.execute('SELECT * FROM otp_codes WHERE phone=? AND expires_at>? AND verified=0 ORDER BY id DESC LIMIT 1',(phone,now)).fetchone()
    if not row or row['attempts']>=5: c.close(); return False
    if row['code_hash']!=digest: c.execute('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?',(row['id'],)); c.commit(); c.close(); return False
    c.execute('UPDATE otp_codes SET verified=1 WHERE id=?',(row['id'],)); c.commit(); c.close(); return True

def admin_required(fn):
    @wraps(fn)
    def wrapper(*a,**kw):
        if not session.get('admin'): return redirect(url_for('admin_login',next=request.path))
        return fn(*a,**kw)
    return wrapper

def prices():
    c=db(); rows=c.execute('SELECT * FROM prices WHERE active=1 ORDER BY id').fetchall(); c.close(); return rows

def price_map(): return {r['code']:r['amount'] for r in prices()}
def service_by_code(code): return next((s for s in SERVICES if s['code']==code),None)
def status_label(s): return {'received':'سفارش ثبت شد','processing':'در حال انجام','ready':'آماده تحویل','courier':'تحویل به پیک / ارسال شد','delivered':'تحویل شد','cancelled':'لغو شد'}.get(s,s)
STATUS_FLOW=['received','processing','ready','courier','delivered']
STATUS_ICONS={'received':'🧾','processing':'⚙️','ready':'📦','courier':'🚚','delivered':'✅'}

def cart_items(): return session.get('cart',[])
def cart_count(): return sum(int(x.get('quantity',1)) for x in cart_items())
def cart_total(): return sum(int(x.get('amount',0)) for x in cart_items())

def captcha_new():
    alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    code=''.join(secrets.choice(alphabet) for _ in range(5))
    session['captcha_code']=code
    return code

def captcha_valid(value):
    expected=str(session.get('captcha_code','')).upper()
    return bool(expected) and str(value or '').strip().upper()==expected

@app.context_processor
def common():
    return {'production':USE_POSTGRES,'shop_name':SHOP_NAME,'shop_phone':SHOP_PHONE,'shop_address':SHOP_ADDRESS,'site_url':SITE_URL,'services':SERVICES,'status_label':status_label,'paper_options':PAPER_OPTIONS,'cart_count':cart_count(),'cart_total':cart_total(),'current_user':session.get('user_name')}

@app.route('/')
def index():
    c=db(); products=c.execute('SELECT * FROM products WHERE active=1 ORDER BY id DESC').fetchall(); c.close()
    stationery=[p for p in products if (p['category'] or 'stationery')=='stationery']
    printing=[p for p in products if p['category']=='printing']
    banners=[p for p in products if p['category']=='banner']
    memorials=[p for p in products if p['category']=='memorial']
    portfolio=[p for p in products if p['category']=='portfolio']
    return render_template('index.html',prices=prices(),price_map=price_map(),products=products,stationery=stationery,printing=printing,banners=banners,memorials=memorials,portfolio=portfolio)

@app.route('/catalog/<category>')
def catalog(category):
    labels={'stationery':'لوازم‌التحریر','printing':'چاپ','banner':'چاپ بنر','memorial':'آگهی ترحیم','portfolio':'نمونه‌کارهای مغازه'}
    if category not in labels: return redirect(url_for('index'))
    c=db(); products=c.execute("SELECT * FROM products WHERE active=1 AND category=? ORDER BY id ASC",(category,)).fetchall(); c.close()
    if category == 'banner':
        return render_template('banner.html', category=category, category_title=labels[category], products=products)
    if category == 'memorial':
        return render_template('memorial.html', category=category, category_title=labels[category], products=products)
    if category == 'printing':
        return render_template('printing.html', category=category, category_title=labels[category], products=products)
    return render_template('catalog.html',category=category,category_title=labels[category],products=products)

@app.route('/auth', methods=['GET','POST'])
def auth():
    mode=request.args.get('mode','login')
    if mode not in {'login','register'}: mode='login'
    if request.method=='POST':
        action=request.form.get('action','login')
        mode=action if action in {'login','register'} else mode
        username=request.form.get('username','').strip().lower()
        password=request.form.get('password','')
        captcha=request.form.get('captcha','')
        if not _rate_ok('auth:'+request.remote_addr, limit=12, window=300):
            flash('تعداد تلاش‌ها زیاد است. چند دقیقه بعد دوباره تلاش کنید.','error'); captcha_new(); return render_template('auth.html',mode=mode)
        if not captcha_valid(captcha):
            flash('کد کپچا صحیح نیست. دوباره تلاش کنید.','error')
            captcha_new()
            return render_template('auth.html',mode=mode)
        if action=='register':
            name=request.form.get('name','').strip(); phone=normalize_phone(request.form.get('phone',''))
            if not name or not re.fullmatch(r'[a-z0-9_.-]{4,32}',username):
                flash('نام کاربری باید ۴ تا ۳۲ کاراکتر انگلیسی، عدد، نقطه، خط تیره یا زیرخط باشد.','error'); captcha_new(); return render_template('auth.html',mode='register')
            if len(password)<8:
                flash('رمز عبور باید حداقل ۸ کاراکتر باشد.','error'); captcha_new(); return render_template('auth.html',mode='register')
            if phone and not valid_phone(phone):
                flash('شماره موبایل معتبر وارد کنید یا آن را خالی بگذارید.','error'); captcha_new(); return render_template('auth.html',mode='register')
            c=db()
            try:
                c.execute('INSERT INTO users(username,name,phone,password_hash,created_at) VALUES(?,?,?,?,?)',(username,name,phone,generate_password_hash(password),int(time.time())))
                c.commit()
            except Exception as e:
                if USE_POSTGRES and isinstance(e, pg_errors.UniqueViolation): pass
                elif not USE_POSTGRES and isinstance(e, sqlite3.IntegrityError): pass
                else: raise
                c.close(); flash('این نام کاربری قبلاً ثبت شده است.','error'); captcha_new(); return render_template('auth.html',mode='register')
            c.close(); session['user_id']=c.lastrowid if False else None
            # Reload id safely after insert/commit.
            c=db(); row=c.execute('SELECT id FROM users WHERE username=?',(username,)).fetchone(); c.close()
            session['user_id']=row['id']; session['user_name']=name; session['username']=username; session.pop('captcha_code',None)
            flash('ثبت‌نام با موفقیت انجام شد. خوش آمدید.','ok'); return redirect(url_for('index'))
        c=db(); row=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
        if not row or not check_password_hash(row['password_hash'],password):
            c.close(); flash('نام کاربری یا رمز عبور صحیح نیست.','error'); captcha_new(); return render_template('auth.html',mode='login')
        c.execute('UPDATE users SET last_login=? WHERE id=?',(int(time.time()),row['id'])); c.commit(); c.close()
        session['user_id']=row['id']; session['user_name']=row['name']; session['username']=row['username']; session.pop('captcha_code',None)
        flash('با موفقیت وارد شدید.','ok'); return redirect(url_for('index'))
    captcha_new()
    return render_template('auth.html',mode=mode)

@app.get('/logout')
def logout():
    for key in ('user_id','user_name','username'):
        session.pop(key,None)
    flash('از حساب کاربری خارج شدید.','ok')
    return redirect(url_for('index'))

@app.get('/captcha.svg')
def captcha_svg():
    code=captcha_new()
    import html
    lines=[]
    for i in range(7):
        x1=10+secrets.randbelow(150); y1=8+secrets.randbelow(42); x2=10+secrets.randbelow(150); y2=8+secrets.randbelow(42)
        lines.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#{secrets.choice(["0b63ce","f72585","7c3aed","00a6a6"])}" stroke-width="1.4" opacity=".55"/>')
    chars=[]
    for i,ch in enumerate(code):
        chars.append(f'<text x="{20+i*28}" y="38" font-size="25" font-family="Arial" font-weight="700" transform="rotate({secrets.randbelow(21)-10} {20+i*28} 30)" fill="#0b2a4a">{html.escape(ch)}</text>')
    svg='<svg xmlns="http://www.w3.org/2000/svg" width="170" height="56" viewBox="0 0 170 56"><rect width="170" height="56" rx="12" fill="#f3f8ff"/><circle cx="20" cy="15" r="2" fill="#f72585"/><circle cx="145" cy="43" r="2" fill="#0b63ce"/>'+''.join(lines)+''.join(chars)+'</svg>'
    return app.response_class(svg,mimetype='image/svg+xml',headers={'Cache-Control':'no-store, no-cache, must-revalidate, max-age=0'})

@app.route('/order',methods=['GET','POST'])
def order():
    if request.method=='POST':
        action=request.form.get('action','send_otp'); phone=normalize_phone(request.form.get('phone',''))
        if action=='send_otp':
            if not _rate_ok('otp:'+request.remote_addr+':'+phone, limit=4, window=600):
                flash('تعداد درخواست کد زیاد است. چند دقیقه بعد دوباره تلاش کنید.','error'); return redirect(url_for('order',service=request.form.get('service','')))
            if not valid_phone(phone): flash('شماره موبایل را به شکل 09xxxxxxxxx وارد کنید.','error'); return redirect(url_for('order',service=request.form.get('service','')))
            if not create_otp(phone): flash('ارسال کد تایید انجام نشد. تنظیمات پیامک را بررسی کنید.','error'); return redirect(url_for('order',service=request.form.get('service','')))
            session['otp_phone']=phone; session['otp_next_service']=request.form.get('service',''); flash('کد ۶ رقمی برای شما ارسال شد.','ok'); return redirect(url_for('verify_phone'))
        if action in {'add_to_cart','create_order'}:
            if session.get('verified_phone')!=phone: flash('ابتدا شماره موبایل را تایید کنید.','error'); return redirect(url_for('order',service=request.form.get('service','')))
            service=service_by_code(request.form.get('service',''))
            if not service: flash('خدمت انتخاب‌شده معتبر نیست.','error'); return redirect(url_for('order'))
            try: qty=max(1,min(1000,int(request.form.get('quantity','1') or 1)))
            except (TypeError,ValueError): flash('تعداد باید بین ۱ تا ۱۰۰۰ باشد.','error'); return redirect(url_for('order',service=service['code']))
            size=request.form.get('size','').strip(); paper=request.form.get('paper','').strip(); duplex=request.form.get('duplex','یک‌رو').strip(); options=request.form.get('options','').strip()
            if size not in service['sizes']:
                flash('اندازه انتخاب‌شده معتبر نیست.','error'); return redirect(url_for('order',service=service['code']))
            if service.get('paper') and paper not in PAPER_MAP:
                flash('نوع کاغذ را انتخاب کنید.','error'); return redirect(url_for('order',service=service['code']))
            key=f'{service["price_code"]}_{size}'+(f'_{paper}' if service.get('paper') else '')
            unit_price=price_map().get(key)
            if unit_price is None or int(unit_price) <= 0: flash('قیمت این گزینه هنوز توسط مدیریت تعیین نشده است.','error'); return redirect(url_for('order',service=service['code']))
            f=request.files.get('file')
            if service['needs_file'] and (not f or not f.filename): flash('برای این خدمت فایل را انتخاب کنید.','error'); return redirect(url_for('order',service=service['code']))
            stored=''; original=''
            if f and f.filename:
                ext=f.filename.rsplit('.',1)[-1].lower() if '.' in f.filename else ''
                if ext not in ALLOWED: flash('فرمت فایل پشتیبانی نمی‌شود.','error'); return redirect(url_for('order',service=service['code']))
                if f.content_length and f.content_length > 25*1024*1024: flash('حجم فایل بیش از ۲۵ مگابایت است.','error'); return redirect(url_for('order',service=service['code']))
                code='DFG-'+secrets.token_hex(4).upper(); original=secure_filename(f.filename)[:120]; stored=f'{code}_{secrets.token_hex(10)}.{ext}'; f.save(PRIVATE_UPLOADS/stored)
            item={'kind':'service','service_code':service['code'],'title':service['title'],'size':size,'quantity':qty,'duplex':duplex,'paper':PAPER_MAP.get(paper,''),'options':options,'amount':unit_price*qty,'unit_price':unit_price,'filename':original,'stored_name':stored}
            cart=session.get('cart',[]); cart.append(item); session['cart']=cart; session.modified=True
            flash('خدمت به سبد خرید اضافه شد.','ok')
            return redirect(url_for('cart'))
    selected=request.args.get('service','')
    return render_template('order.html',price_map=price_map(),selected=selected,verified=bool(session.get('verified_phone')))

@app.post('/cart/add-product/<int:product_id>')
def add_product_to_cart(product_id):
    c=db(); product=c.execute('SELECT * FROM products WHERE id=? AND active=1',(product_id,)).fetchone(); c.close()
    if not product: flash('محصول پیدا نشد.','error'); return redirect(url_for('index')+'#stationery')
    if int(product['price'] or 0) <= 0:
        flash('قیمت این محصول هنوز در پنل مدیریت تعیین نشده است.','error'); return redirect(url_for('catalog',category=product['category']))
    cart=session.get('cart',[]); cart.append({'kind':'product','product_id':product_id,'title':product['name'],'quantity':1,'amount':int(product['price']),'description':product['description'] or ''}); session['cart']=cart; session.modified=True
    flash('محصول به سبد خرید اضافه شد.','ok'); return redirect(url_for('cart'))

@app.route('/cart')
def cart(): return render_template('cart.html',items=cart_items(),total=cart_total())

@app.post('/cart/remove/<int:index>')
def cart_remove(index):
    cart=session.get('cart',[])
    if 0 <= index < len(cart): cart.pop(index); session['cart']=cart; session.modified=True
    return redirect(url_for('cart'))

@app.post('/cart/clear')
def cart_clear(): session.pop('cart',None); return redirect(url_for('cart'))

@app.route('/checkout')
def checkout():
    if not cart_items(): return redirect(url_for('cart'))
    return render_template('checkout.html',items=cart_items(),total=cart_total())

@app.post('/cart/checkout')
def cart_checkout():
    if not cart_items(): flash('سبد خرید خالی است.','error'); return redirect(url_for('cart'))
    if not session.get('verified_phone'):
        flash('برای ادامه پرداخت، ابتدا شماره موبایل را تایید کنید.','error'); return redirect(url_for('order'))
    return redirect(url_for('checkout'))

@app.route('/verify-phone',methods=['GET','POST'])
def verify_phone():
    phone=session.get('otp_phone')
    if not phone: return redirect(url_for('order'))
    if request.method=='POST':
        if verify_otp(phone,request.form.get('otp','').strip()): session['verified_phone']=phone; session.pop('otp_phone',None); next_service=session.pop('otp_next_service',''); flash('شماره موبایل تایید شد.','ok'); return redirect(url_for('order',service=next_service))
        flash('کد نادرست یا منقضی شده است.','error')
    return render_template('verify_phone.html',phone=phone,dev_otp=session.get('dev_otp_code'))

@app.route('/lucky-wheel', methods=['GET','POST'])
def lucky_wheel():
    result=None; phone=session.get('verified_phone','')
    if request.method=='POST':
        phone=normalize_phone(request.form.get('phone','')) or normalize_phone(session.get('verified_phone',''))
        if not valid_phone(phone):
            flash('شماره موبایل معتبر وارد کنید.','error')
            return render_template('lucky_wheel.html', result=None, phone=phone)
        day_key=time.strftime('%Y-%m-%d', time.localtime())
        c=db(); old=c.execute('SELECT result FROM lucky_spins WHERE phone=? AND day_key=? ORDER BY id DESC LIMIT 1',(phone,day_key)).fetchone()
        if old:
            result=old['result']
        else:
            # The wheel has two equally visible outcomes; the result is stored for the owner.
            result=secrets.choice(['۵٪ تخفیف','فردا دوباره تلاش کن'])
            c.execute('INSERT INTO lucky_spins(phone,result,day_key) VALUES(?,?,?)',(phone,result,day_key)); c.commit()
        c.close()
    return render_template('lucky_wheel.html', result=result, phone=phone)

@app.route('/track',methods=['GET','POST'])
def track():
    order_row=None
    if request.method=='POST':
        if not _rate_ok('track:'+request.remote_addr, limit=20, window=300):
            flash('تعداد درخواست‌های پیگیری زیاد است. کمی بعد دوباره تلاش کنید.','error')
            return render_template('track.html',order=None,status_flow=STATUS_FLOW,status_icons=STATUS_ICONS)
        code=request.form.get('order_code','').strip().upper(); phone=normalize_phone(request.form.get('phone','')); c=db(); order_row=c.execute('SELECT * FROM orders WHERE order_code=? AND phone=?',(code,phone)).fetchone(); c.close()
        if not order_row: flash('سفارش با این کد و شماره موبایل پیدا نشد.','error')
    return render_template('track.html',order=order_row,status_flow=STATUS_FLOW,status_icons=STATUS_ICONS)

@app.post('/track/confirm-receipt')
def confirm_receipt():
    code=request.form.get('order_code','').strip().upper(); phone=normalize_phone(request.form.get('phone',''))
    c=db(); row=c.execute('SELECT * FROM orders WHERE order_code=? AND phone=?',(code,phone)).fetchone()
    if not row:
        c.close(); flash('سفارش با این کد و شماره موبایل پیدا نشد.','error'); return redirect(url_for('track'))
    if row['status'] != 'courier':
        c.close(); flash('تأیید دریافت فقط پس از تحویل سفارش به پیک/ارسال فعال می‌شود.','error'); return redirect(url_for('track'))
    c.execute("UPDATE orders SET status='delivered',updated_at=CURRENT_TIMESTAMP WHERE id=?",(row['id'],)); c.commit(); c.close()
    flash('دریافت سفارش با موفقیت تأیید شد. ممنون از شما 🌷','ok'); return redirect(url_for('track'))

@app.route('/uploads/<path:name>')
def uploaded(name):
    # Only public product/placeholder assets are served here. Customer documents stay private.
    if not (name.startswith(('product_','stationery_','memorial_demo_','portfolio_demo_','printing_demo_','banner_demo_')) or name.startswith('stationery_real/')):
        abort(404)
    return send_from_directory(PUBLIC_UPLOADS,name)

@app.get('/admin/orders/<int:order_id>/file')
@admin_required
def private_order_file(order_id):
    c=db(); row=c.execute('SELECT stored_name,filename FROM orders WHERE id=?',(order_id,)).fetchone(); c.close()
    if not row or not row['stored_name']: abort(404)
    return send_from_directory(PRIVATE_UPLOADS,row['stored_name'],as_attachment=True,download_name=row['filename'] or row['stored_name'])

@app.route('/admin/login',methods=['GET','POST'])
def admin_login():
    if request.method=='POST':
        if not _rate_ok('admin:'+request.remote_addr, limit=8, window=300):
            flash('تلاش‌های ورود زیاد است. چند دقیقه بعد دوباره امتحان کنید.','error'); return render_template('admin_login.html')
        supplied=request.form.get('password','')
        admin_hash=os.getenv('ADMIN_PASSWORD_HASH','').strip()
        ok=check_password_hash(admin_hash,supplied) if admin_hash else (request.form.get('username')==ADMIN_USER and secrets.compare_digest(supplied,ADMIN_PASSWORD))
        if request.form.get('username')==ADMIN_USER and ok:
            session['csrf_token']=secrets.token_urlsafe(32); session['admin']=True; return redirect(url_for('admin'))
        flash('نام کاربری یا رمز عبور صحیح نیست.','error')
    return render_template('admin_login.html')
@app.route('/admin/logout')
def admin_logout(): session.pop('admin',None); return redirect(url_for('index'))
@app.route('/admin')
@admin_required
def admin():
    c=db(); orders=c.execute('SELECT * FROM orders ORDER BY id DESC').fetchall(); products=c.execute('SELECT * FROM products ORDER BY id DESC').fetchall(); ps=c.execute('SELECT * FROM prices ORDER BY id').fetchall(); spins=c.execute('SELECT * FROM lucky_spins ORDER BY id DESC LIMIT 300').fetchall(); c.close(); return render_template('admin.html',orders=orders,products=products,prices=ps,spins=spins)
@app.post('/admin/prices')
@admin_required
def admin_prices():
    c=db()
    for r in c.execute('SELECT id FROM prices').fetchall():
        raw=request.form.get(f'price_{r['id']}','').replace(',','').strip()
        if raw.isdigit(): c.execute('UPDATE prices SET amount=? WHERE id=?',(int(raw),r['id']))
    c.commit(); c.close(); flash('قیمت‌ها ذخیره شد.','ok'); return redirect(url_for('admin')+'#prices')
@app.post('/admin/orders/<int:order_id>/status')
@admin_required
def update_order(order_id):
    status=request.form.get('status','received'); allowed={'received','processing','ready','courier','delivered','cancelled'}
    if status not in allowed: return ('bad status',400)
    c=db(); c.execute('UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,order_id)); c.commit(); c.close(); return redirect(url_for('admin')+'#orders')

@app.post('/admin/products/save')
@admin_required
def save_product():
    pid=request.form.get('id','').strip(); name=request.form.get('name','').strip(); desc=request.form.get('description','').strip()
    category=request.form.get('category','stationery').strip()
    subcategory=request.form.get('subcategory','').strip()
    if category not in {'stationery','printing','banner','memorial','portfolio'}: category='stationery'
    raw_price=request.form.get('price','').strip().replace(',','')
    try: price=int(raw_price) if raw_price else 0
    except (TypeError,ValueError): price=-1
    if not name or price<0: flash('نام محصول معتبر است؛ قیمت می‌تواند فعلاً خالی باشد.','error'); return redirect(url_for('admin')+'#products')
    f=request.files.get('image'); image=''
    if f and f.filename:
        ext=f.filename.rsplit('.',1)[-1].lower()
        if ext not in {'jpg','jpeg','png','webp'}: flash('فرمت عکس نامعتبر است.','error'); return redirect(url_for('admin')+'#products')
        image='product_'+secrets.token_hex(5)+'.webp'
        try:
            if f.content_length and f.content_length > 8*1024*1024: flash('حجم تصویر بیش از ۸ مگابایت است.','error'); return redirect(url_for('admin')+'#products')
            from PIL import Image, ImageOps
            Image.MAX_IMAGE_PIXELS=20_000_000
            f.stream.seek(0)
            im0=Image.open(f); im0.verify()
            f.stream.seek(0)
            im=Image.open(f); im=ImageOps.exif_transpose(im).convert('RGB')
            # Preserve the product's natural aspect ratio; only downscale very large uploads.
            im.thumbnail((1400,1050),Image.Resampling.LANCZOS)
            im.save(PUBLIC_UPLOADS/image,'WEBP',quality=94,method=6)
        except Exception:
            image='product_'+secrets.token_hex(5)+'.'+ext; f.save(PUBLIC_UPLOADS/image)
    c=db()
    if pid:
        if image: c.execute('UPDATE products SET name=?,description=?,price=?,image=?,category=?,subcategory=? WHERE id=?',(name,desc,price,image,category,subcategory,int(pid)))
        else: c.execute('UPDATE products SET name=?,description=?,price=?,category=?,subcategory=? WHERE id=?',(name,desc,price,category,subcategory,int(pid)))
    else:
        c.execute('INSERT INTO products(name,description,price,image,category,subcategory) VALUES(?,?,?,?,?,?)',(name,desc,price,image,category,subcategory))
    c.commit(); c.close(); flash('مورد ذخیره شد؛ عکس برای نمایش فروشگاهی آماده شد.','ok'); return redirect(url_for('admin')+'#products')
@app.post('/admin/products/<int:product_id>/toggle')
@admin_required
def toggle_product(product_id):
    c=db(); c.execute('UPDATE products SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?',(product_id,)); c.commit(); c.close(); return redirect(url_for('admin')+'#products')
@app.get('/health')
def health():
    return jsonify({'status':'ok','service':'daftar-fani-gharb'})

@app.get('/api/services')
def api_services(): return jsonify(SERVICES)
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','5000')),debug=False)
