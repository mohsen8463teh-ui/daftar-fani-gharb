(function(){
 const data=window.ORDER_DATA;if(!data)return;
 const selected=data.selected;if(!selected)return;
 const s=data.services.find(x=>x.code===selected); if(!s)return;
 const size=document.getElementById('size'),qty=document.getElementById('quantity'),paper=document.getElementById('paper'),paperBox=document.getElementById('paperBox'),filebox=document.getElementById('filebox'),duplexRow=document.getElementById('duplexRow'),extra=document.getElementById('serviceSpecific'),estimate=document.getElementById('estimate'),note=document.getElementById('estimateNote');
 if(!size)return;
 size.innerHTML=s.sizes.map(x=>`<option value="${x}">${x}</option>`).join('');
 const a4=size.querySelector('option[value="A4"]'); if(a4) a4.selected=true;
 const paperServices=new Set(['copy_bw','copy_color','print_bw','print_color']);
 paperBox.style.display=s.paper?'block':'none';
 duplexRow.style.display=(s.code.startsWith('copy')||s.code.startsWith('print')||s.code.startsWith('plot'))?'grid':'none';
 filebox.style.display=s.needs_file?'block':'none';
 const extras={
  copy_bw:'فایل را با کیفیت مناسب ارسال کنید؛ خروجی فقط سیاه‌وسفید خواهد بود.',copy_color:'خروجی رنگی است؛ نوع کاغذ را از فهرست بالا انتخاب کنید.',
  print_bw:'فایل آماده چاپ را ارسال کنید؛ خروجی فقط سیاه‌وسفید خواهد بود.',print_color:'فایل آماده چاپ را ارسال کنید؛ خروجی رنگی است.',
  plot_bw:'سایز پلات را انتخاب کنید. برای نقشه‌ها مقیاس را در توضیحات بنویسید.',plot_color:'سایز پلات را انتخاب کنید و در صورت نیاز مقیاس را در توضیحات بنویسید.',
  scan_color_bw:'اصل مدرک را برای اسکن رنگی و سیاه‌وسفید ارائه کنید.',binding_spiral:'تعداد صفحات و رنگ فنر را در توضیحات بنویسید.',binding_cover_strip:'نوع طلق، رنگ شیرازه و تعداد صفحات را در توضیحات بنویسید.',laminate:'سایز لمینت را انتخاب کنید؛ سایزهای A5، A4، A3 و A2 در دسترس هستند.'};
 extra.innerHTML=`<div class="hint-card">${extras[s.code]||''}</div>`;
 function calc(){
  const n=Math.max(1,parseInt(qty.value||1)); const key=s.price_code+'_'+size.value+(s.paper?('_'+paper.value):''); const unit=data.prices[key]||0;
  estimate.textContent=unit>0 ? new Intl.NumberFormat('fa-IR').format(unit*n)+' تومان' : 'قیمت پس از تعیین توسط مدیریت';
  note.textContent=s.paper?'نوع کاغذ فقط برای کپی و پرینت قابل انتخاب است.':'قیمت پس از تعیین در پنل مدیریت نمایش داده می‌شود.';
 }
 size.addEventListener('change',calc); qty.addEventListener('input',calc); if(paper)paper.addEventListener('change',calc); calc();
})();
