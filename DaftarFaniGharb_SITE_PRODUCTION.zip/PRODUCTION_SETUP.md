# Production deployment – Daftar Fani Gharb

This build is prepared for Render with PostgreSQL support.

## Required Render environment variables

- `DATABASE_URL` — provided by the Render PostgreSQL database
- `SECRET_KEY` — long random secret
- `ADMIN_USER` — admin username
- `ADMIN_PASSWORD_HASH` — Werkzeug password hash for the admin password
- `SITE_URL` — final HTTPS site URL
- `COOKIE_SECURE=1`
- `SMS_PROVIDER_URL`, `SMS_API_KEY`, `SMS_SENDER` — required before real customer OTP verification is enabled

## Persistent files

The application reads `DATA_DIR` for SQLite fallback and upload storage. For production, customer-uploaded files must be placed on a Render Persistent Disk (for example `DATA_DIR=/var/data`). The database itself is PostgreSQL.

Do not deploy production without persistent storage for customer files.
