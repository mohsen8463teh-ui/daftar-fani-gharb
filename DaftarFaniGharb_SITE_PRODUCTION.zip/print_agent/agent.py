"""
Print Agent برای لپ‌تاپ مغازه
--------------------------------
این برنامه نمونه‌ی عامل چاپ است:
- صف /api/print-queue را می‌خواند.
- فایل سفارش را دریافت می‌کند.
- وضعیت را به printing تغییر می‌دهد (نسخه تولیدی باید endpoint احراز هویت‌شده داشته باشد).
- برای PDF می‌تواند SumatraPDF را اجرا کند.
- برای پرینترها باید نام واقعی Queue ویندوز در config.ini وارد شود.

نکته: این عامل را فقط روی لپ‌تاپ مغازه اجرا کنید و سرور را با HTTPS و توکن امن منتشر کنید.
"""
import time, os, configparser, requests, subprocess
from pathlib import Path

cfg=configparser.ConfigParser()
cfg.read("agent.ini")
BASE_URL=cfg.get("server","base_url",fallback="http://127.0.0.1:5000")
DOWNLOAD_DIR=Path(cfg.get("agent","download_dir",fallback="./downloads")); DOWNLOAD_DIR.mkdir(exist_ok=True)
SUMATRA=cfg.get("agent","sumatra_pdf",fallback="SumatraPDF.exe")

def get_queue():
    return requests.get(BASE_URL+"/api/print-queue",timeout=15).json()

def download(oid,name):
    r=requests.get(BASE_URL+f"/api/orders/{oid}/file",timeout=60)
    r.raise_for_status()
    p=DOWNLOAD_DIR/name
    p.write_bytes(r.content)
    return p

def print_pdf(path,printer=None):
    cmd=[SUMATRA,"-print-to-default",str(path)]
    if printer:
        cmd=[SUMATRA,"-print-to",printer,str(path)]
    subprocess.run(cmd,check=True)

while True:
    try:
        for order in get_queue():
            oid=order["id"]
            # Production: call authenticated "printing" endpoint first.
            f=download(oid,order["stored_name"])
            if f.suffix.lower()==".pdf":
                print_pdf(f,order.get("printer") or None)
                requests.post(BASE_URL+f"/api/orders/{oid}/printed",timeout=15)
            else:
                print(f"دستور چاپ خودکار برای {f.suffix} نیاز به مبدل/نرم‌افزار مناسب دارد: {f}")
    except Exception as e:
        print("Agent error:",e)
    time.sleep(10)
